using TechTalk.SpecFlow;
//using SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using System.Net;
using System.Net.Http;
using NUnit.Framework;
using System;

namespace BankAssignment.Steps
{
    [Binding]
    public sealed class BookRoomsStepsdefinition
    {
        private IWebDriver driver;
        private BookRoom book;
        private BookingDetails BookDetails;
        
        [Given(@"I Open the Browser")]
        public void OpenTheBrowser()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        [Given(@"I Enter the Shady Meadows Bed and Breakfast URL")]
        public void AutomationExerciseURL()
        {
            driver.Navigate().GoToUrl("https://automationintesting.online/");
        }

        [Given(@"I Click on BookThisRoom button")]
        public void ClickBookRoomButton()
        {
            Thread.Sleep(1000);
            book = new BookRoom(driver);
            book.BookThisRoom();
        }

        [Given(@"I select Booking startDate and EndDate")]
        public void SelectBookingDays()
        {
            Thread.Sleep(1000);
            book = new BookRoom(driver);
            book.Bookingdays();
            Thread.Sleep(2000);
        }

        [Given(@"I Enter the FirstName")]
        public void FillFirstName()
        {
            Thread.Sleep(1000);
            BookDetails = new BookingDetails(driver);
            BookDetails.BookingFormFirstName();
        }

        [Given(@"I Enter the LastName")]
        public void FillLastName()
        {
            Thread.Sleep(1000);
            BookDetails = new BookingDetails(driver);
            BookDetails.BookingFormLastName();
        }

        [Given(@"I Enter the Email")]
        public void FillEmail()
        {
            Thread.Sleep(1000);
            BookDetails = new BookingDetails(driver);
            BookDetails.BookingFormEmail();
        }

         [Given(@"I Enter the Phone")]
        public void FillPhone()
        {
            Thread.Sleep(1000);
            BookDetails = new BookingDetails(driver);
            BookDetails.BookingFormPhone();
        }

        [Then(@"I Click the Book button")]
        public void Loginbutton()
        {
            Thread.Sleep(1000);
            BookDetails = new BookingDetails(driver);
            BookDetails.ClickBookButton();
        }
            
    }
}
