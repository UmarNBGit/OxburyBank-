﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Threading;
using NUnit.Framework;

namespace BankAssignment;

public class BookingDetails
{
     private IWebDriver driver;
     private Localization location;

    public BookingDetails(IWebDriver browser)
    {
        driver = browser;
        location = new Localization(driver);
    }

    public void BookingFormFirstName()
        {
            //login = new UserLogin(driver);
            location = new Localization(driver);
            string fName = Credentials.firstName;
            location.FirstName.SendKeys(fName);
             if (string.IsNullOrEmpty(fName))
            {
               Console.Write(" Please enter First Name");
            }
            
            Thread.Sleep(2000);
        }
        public void BookingFormLastName()
        {
            location = new Localization(driver);
            string lName = Credentials.lastName;
            location.LastName.SendKeys(lName);
             if (string.IsNullOrEmpty(lName))
            {
               Console.Write(" Please enter last Name");
            }
            Thread.Sleep(2000);

            location.BookOrder.Click();
        }
        public void BookingFormEmail()
        {
            location = new Localization(driver);
            string eMail = Credentials.email;
            location.Emailadd.SendKeys(eMail);
             if (string.IsNullOrEmpty(eMail))
            {
               Console.Write(" Please enter Email");
            }
            Thread.Sleep(2000);
        }

        public void BookingFormPhone()
        {
            string phone = Credentials.phone;
            location = new Localization(driver);
            location.PhoneNr.SendKeys(phone);
             if (string.IsNullOrEmpty(phone))
            {
               Console.Write(" Please enter Phone");
            }
            Thread.Sleep(2000);
        }

        public void ClickBookButton()
        {    
            location = new Localization(driver);
            location.BookOrder.Click();
            Thread.Sleep(2000);
        }


        

}