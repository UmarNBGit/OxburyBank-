﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Threading;
using NUnit.Framework;
using Gherkin.Ast;

namespace BankAssignment;

public class BookRoom
{
     private IWebDriver driver;
     private Localization location;

    public BookRoom(IWebDriver browser)
    {
        driver = browser;
        location = new Localization(driver);
    }

    public void BookThisRoom() => location.BookRoom.Click();
    public void Bookingdays() => location.BookingDates();
    
}