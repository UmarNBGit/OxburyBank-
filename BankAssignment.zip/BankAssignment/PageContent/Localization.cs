﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using BankAssignment.Drivers;

namespace BankAssignment;

public class Localization
{
    private IWebDriver driver;
   public Localization(IWebDriver browser)
    {
        driver = browser;
    }

    // Booking Elemets
    private By BookR = By.XPath("//button[normalize-space()='Book this room']");
    public IWebElement BookRoom => driver.FindElement(BookR);

    public void BookingDates()
        {         
            IWebElement StartDate = driver.FindElement(By.XPath("//div[5]//div[2]//div[1]//div[4]")); 
            IWebElement EndDate = driver.FindElement(By.XPath("//div[5]//div[2]//div[1]//div[7]"));
            Actions action = new Actions(driver);
            action.MoveToElement(StartDate).ClickAndHold().Perform();
            action.MoveToElement(EndDate).Release().Perform();
        }
    
    // Booking Details //div[5]//div[2]//div[1]//div[4]
    private By FirstN = By.XPath("//input[@placeholder='Firstname']");
    public IWebElement FirstName => driver.FindElement(FirstN);
    private By LastN = By.XPath("//input[@placeholder='Lastname']");
    public IWebElement LastName => driver.FindElement(LastN);
    private By Email = By.XPath("//input[@name='email']");
    public IWebElement Emailadd => driver.FindElement(Email);
    private By Tlf = By.XPath("//input[@name='phone']");
    public IWebElement PhoneNr => driver.FindElement(Tlf);

    private By bookbtn = By.XPath("//button[normalize-space()='Book']");
    public IWebElement BookOrder => driver.FindElement(bookbtn);

}
