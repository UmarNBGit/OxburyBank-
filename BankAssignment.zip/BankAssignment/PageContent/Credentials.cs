using System;

namespace BankAssignment;

public class Credentials
{
    public const string firstName = "Oxbury";
    public const string lastName = "Bank";
    public const string email = "u.buttar@gmail.com";
    public const string phone = "07123007477";
}